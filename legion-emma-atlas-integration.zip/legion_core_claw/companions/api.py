"""Opt-in FastAPI router for the two companions.

This is an integration scaffold, not an LLM provider. Inject a callable
responder to connect an approved model backend. No tools are executed here.
"""
from typing import Callable, Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from .profiles import PROFILES, AgentProfile, get_profile

class ChatRequest(BaseModel):
    agent_id: str = Field(..., min_length=1, max_length=32)
    message: str = Field(..., min_length=1, max_length=8000)

class ChatResponse(BaseModel):
    agent_id: str
    reply: str
    simulated: bool

def create_companion_router(
    responder: Optional[Callable[[AgentProfile, str], str]] = None,
) -> APIRouter:
    router = APIRouter(prefix="/api/companions", tags=["companions"])

    @router.get("/agents")
    def list_companions():
        return [
            {"id": p.id, "display_name": p.display_name,
             "role": p.role, "allowed_capabilities": list(p.allowed_capabilities)}
            for p in PROFILES.values()
        ]

    @router.post("/chat", response_model=ChatResponse)
    def chat(request: ChatRequest):
        try:
            profile = get_profile(request.agent_id)
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc))
        if not request.message.strip():
            raise HTTPException(status_code=422, detail="Message cannot be blank")
        if responder is None:
            return ChatResponse(
                agent_id=profile.id,
                reply=f"{profile.display_name} is configured; connect an LLM responder to enable live chat.",
                simulated=True,
            )
        try:
            reply = responder(profile, request.message)
        except Exception:
            # Avoid leaking provider secrets or internal errors to API clients.
            raise HTTPException(status_code=502, detail="Companion backend unavailable")
        if not isinstance(reply, str) or not reply.strip():
            raise HTTPException(status_code=502, detail="Companion backend returned no reply")
        return ChatResponse(agent_id=profile.id, reply=reply, simulated=False)

    return router
