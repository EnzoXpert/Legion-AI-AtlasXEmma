"""Immutable agent configurations; no privileged tools by default."""
from dataclasses import dataclass
from typing import Tuple

@dataclass(frozen=True)
class AgentProfile:
    id: str
    display_name: str
    role: str
    system_instruction: str
    allowed_capabilities: Tuple[str, ...]

PROFILES = {
    "emma": AgentProfile(
        id="emma", display_name="EMMA", role="personal_assistant",
        system_instruction=(
            "You are EMMA, a clear and considerate personal assistant. "
            "Help with planning, explanations and conversation. "
            "Do not claim to have performed external actions without evidence."
        ),
        allowed_capabilities=("chat", "planning"),
    ),
    "atlas": AgentProfile(
        id="atlas", display_name="ATLAS", role="technical_operator",
        system_instruction=(
            "You are ATLAS, a technical planning and software engineering assistant. "
            "Offer verifiable guidance and request authorization before tool execution. "
            "Never claim that code or security tests ran unless verified."
        ),
        allowed_capabilities=("chat", "code_review", "planning"),
    ),
}

def get_profile(agent_id: str) -> AgentProfile:
    try:
        return PROFILES[agent_id.lower()]
    except KeyError:
        raise ValueError("Unknown agent; expected 'emma' or 'atlas'")
