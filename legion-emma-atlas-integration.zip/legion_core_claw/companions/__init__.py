"""EMMA and ATLAS companion integration (opt-in)."""
from .profiles import PROFILES, AgentProfile, get_profile
from .api import create_companion_router
__all__ = ["PROFILES", "AgentProfile", "get_profile", "create_companion_router"]
