# EMMA + ATLAS — opt-in initial integration

This additive module does not replace the existing Legion Core Claw API,
orchestrator, Telegram bot, or dashboard.

## API wiring

In the existing FastAPI application setup, add:

```python
from legion_core_claw.companions import create_companion_router
app.include_router(create_companion_router())
```

Routes:
- `GET /api/companions/agents` — public profile metadata
- `POST /api/companions/chat` — body `{"agent_id":"emma","message":"Hello"}`

By default, chat explicitly returns `simulated: true`; no live LLM is
connected. To connect a model, inject a callable `responder(profile, message)`
that returns text. Handle authentication, rate limiting, model timeouts,
logging redaction, and user-scoped memory before exposing this API publicly.

## Safety and compatibility

- No changes to existing endpoints or orchestration.
- No shell, device, GitHub, or security tool execution.
- The profile instructions are server-side; they are not returned by listing.
- Do not expose this endpoint on the public internet without authentication.
- This patch does not repair unrelated existing repository issues.

## Tests

Install project requirements and `httpx` (needed by FastAPI TestClient
in supported versions), then run:

```bash
python -m pytest tests/test_companions.py -q
```

For the next milestone: authenticated per-user sessions, provider adapters,
persistent memory, audit events, and voice/avatar streaming.
