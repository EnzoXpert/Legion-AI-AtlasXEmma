"""Tests for the opt-in companion router and immutable profiles."""
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from legion_core_claw.companions.api import create_companion_router
from legion_core_claw.companions.profiles import PROFILES, get_profile

def client(responder=None):
    app = FastAPI()
    app.include_router(create_companion_router(responder=responder))
    return TestClient(app)

def test_profiles_are_distinct_and_restricted():
    assert set(PROFILES) == {"emma", "atlas"}
    assert PROFILES["emma"].role != PROFILES["atlas"].role
    assert "execute_tools" not in PROFILES["atlas"].allowed_capabilities
    with pytest.raises(ValueError):
        get_profile("unknown")

def test_agent_listing_excludes_system_instructions():
    response = client().get("/api/companions/agents")
    assert response.status_code == 200
    assert {x["id"] for x in response.json()} == {"emma", "atlas"}
    assert "system_instruction" not in response.text

@pytest.mark.parametrize("agent_id", ["emma", "atlas"])
def test_default_chat_is_explicitly_simulated(agent_id):
    response = client().post("/api/companions/chat",
                             json={"agent_id": agent_id, "message": "Hello"})
    assert response.status_code == 200
    assert response.json()["simulated"] is True
    assert response.json()["agent_id"] == agent_id

def test_responder_receives_selected_profile():
    response = client(lambda profile, message: f"{profile.display_name}: {message}").post(
        "/api/companions/chat", json={"agent_id": "atlas", "message": "Review"})
    assert response.status_code == 200
    assert response.json() == {"agent_id": "atlas", "reply": "ATLAS: Review", "simulated": False}

def test_invalid_agent_and_blank_message():
    c = client()
    assert c.post("/api/companions/chat", json={"agent_id": "other", "message": "Hi"}).status_code == 404
    assert c.post("/api/companions/chat", json={"agent_id": "emma", "message": "  "}).status_code == 422

def test_backend_error_is_sanitized():
    def fail(profile, message):
        raise RuntimeError("SECRET_TOKEN")
    response = client(fail).post("/api/companions/chat",
                                  json={"agent_id": "emma", "message": "Hi"})
    assert response.status_code == 502
    assert "SECRET_TOKEN" not in response.text
